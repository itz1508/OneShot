"""Thin RPC-style CLI."""
